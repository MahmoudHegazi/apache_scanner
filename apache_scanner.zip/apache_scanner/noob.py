#!/usr/bin/python
from bs4 import BeautifulSoup
from tablib import Dataset
import numpy as np
import excel
import matplotlib.pyplot as plt
from flask import Flask, render_template, request, redirect, jsonify, url_for, flash
from sqlalchemy import create_engine, asc
from sqlalchemy.orm import sessionmaker
from database_setup import Base, User, Element, ElementsMeta, Page, Vote
from flask import session as login_session
import string
import excel
# IMPORTS FOR THIS STEP
import httplib2
import json
from flask import make_response
import requests
import pandas as pd
from tablib import Dataset
import numpy as np
import excel
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
# IMPORTS FOR THIS STEP
import pprint
import httplib2
import json
import sqlite3
from flask import make_response
import requests


app = Flask(__name__)

APPLICATION_NAME = "skaner"

# Connect to Database and create database session
engine = create_engine('sqlite:///skanner.db')
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()



# You need install :
# pip install PyPDF2 - > Read and parse your content pdf
# pip install requests - > request for get the pdf
# pip install BeautifulSoup - > for parse the html and find all url hrf with ".pdf" final
from PyPDF2 import PdfFileReader
import requests
import io
from bs4 import BeautifulSoup


@app.route('/skanner/JSON')
def endElements():
    elements = session.query(Element).all()
    return jsonify(Elements=[r.serialize for r in elements])

@app.route('/skanner/meta/JSON')
def endElementsMeta():
    metas = session.query(ElementsMeta).all()
    return jsonify(Elements_meta=[r.serialize for r in metas])

@app.route('/')
def skanner():
    filename = 'index.html'
    # get the name of the page only before the exteniseion
    page_name = filename.split(".")
    page_name = page_name[0]
    if filename:
        print('Creating New Page! ...')
        newpage = Page(page_name=page_name, url=filename)
        session.add(newpage)
        session.commit()
    with open(filename, 'r') as f:
        contents = f.read()
        soup = BeautifulSoup(contents, 'lxml')
        projectData = []
        #projectData.append(str(soup.h2.name))
        #projectData.append(str(soup.h2.text))
        #projectData.append(str(soup.li))
        for child in soup.recursiveChildGenerator():

            if child.name:
                newElement = Element(name=str(child.name),page_id=newpage.id)
                session.add(newElement)
                session.commit()
                # add it first to get the auto insirment id then use the id
                elmid = newElement.id
                elname = str(newElement.name)
                print(str(elmid) + 'yes me')
                print('Skanner Found new Creating New Element... ')
                newMeta = ElementsMeta(name=elname, element_text=str(child.text), element_html=str(child),
                element_id=elmid, page_id=newpage.id)
                print('Creating New Meta... ')
                session.add(newMeta)
                session.commit()
        return "Beauty Skanner Finished His Work Successfuly your data ready!.."


@app.route('/play')
def selector():
    getpages = session.query(Page).all()
    getelem = session.query(Element).all()
    unique_list = []
    for record in getelem:
        object_name = str(record.name)
        if object_name not in unique_list:
            unique_list.append(str(object_name))

    return render_template('play.html', names=unique_list, pages=getpages)


@app.route('/api.skanner_apache', methods=["GET", "POST"])
def api():
    # request.args.get for url parameters
    tag = request.args.get("thename")
    page_id = request.args.get("pageid")

    #return str(tag)
    getpage = session.query(Page).filter_by(id=page_id).first()
    getmeta = session.query(ElementsMeta).filter_by(page_id=getpage.id).all()
    # check if the value of thename parameter = the meta return it my friend
    mytable = "<!doctype html><html><head><meta charset='utf-8'><title>Apache Scanner ( " + getpage.page_name + " )</title>"
    mytable += "<style>table{font-family: arial, sans-serif;border-collapse: collapse;width: 70%;}td, th{border: 1px solid #dddddd;"
    mytable += "text-align: left;padding: 8px;}td:hover{background-color: lightblue;}tr:nth-child(even) {background-color: #dddddd;}</style></head><body>"
    mytable += "<table><tr><th>Page Id</th><th>Page Name</th><th>Page URL</th>"
    mytable += "<th>Tag Name</th><th>Tag Text</th><th>Tag HTML</th><th>Tag Class</th><th>Tag src</th></tr>"
    for elm in getmeta:
        if elm.name == tag:
            mytable += "<tr><td>" + str(getpage.id) + "</td>"
            mytable += "<td>" + str(getpage.page_name) + "</td>"
            mytable += "<td>" + str(getpage.url) + "</td>"
            mytable += "<td>" + str(elm.name) + "</td>"
            mytable += "<td>" + str(elm.element_text) + "</td>"
            mytable += "<td>" + str(elm.element_html) + "</td>"
            mytable += "<td>" + str(elm.element_class) + "</td>"
            mytable += "<td>" + str(elm.element_src) + "</td></tr>"
            #mytable += "<td>" + name.element_id + "</td>"
    mytable += "</table></body></html>"


    #return str(tag)
    #text = ""
    #for i in getmeta:

        #text += "<div style='width:200px;margin-left:auto;margin-right:auto;border:2px solid gold; height:100px;"
        #text += "background-color:lightblue;color:white;text-align:center;'>"
        #text += '<h4>' + str(i.element_text) + '<h4>'
        #text += "</div>"
        #return stri.element_text
    return  mytable
    #return "<a href='/play'><button>Search Again</button></a>" + text

#request.form.getlist('name') use get if the key might not exist
#equest.form.getlist('name'): use getlist if the key
#is sent multiple times and you want a list of values. get only returns the first value.

@app.route('/play/<string:tag_nam>')
def play(tag_nam):
    getelem = session.query(Element).filter_by(name=tag_nam).all()
    text = ""
    for i in getelem:
        text += "<div style='width:200px;margin-left:auto;margin-right:auto;border:2px solid gold; height:100px;"
        text += "background-color:lightblue;color:white;text-align:center;'>"
        text += '<h4>' + str(i.name) + '<h4>'
        text += "</div>"
    return "<a href='/play'><button>Search Again</button></a>" + text


    #element_text = Column(String(255))
    #element_html = Column(String(255))
    #element_class = Column(String(255))
    #element_src = Column(String(500))
    #element_id = Column(Integer, ForeignKey('element.id'))
    #element = relationship(Element)


    #newSeries = Series(name=iname, description=ides, hero=ihero, menu_id=imenuid)
    #imge = newSeries.image



if __name__ == '__main__':
    app.secret_key = 'AS&S^1234Aoshsheo152h23h5j7ks9-1---3*-s,#k>s'
    app.debug = True
    app.run(host='0.0.0.0', port=5000, threaded=False)
