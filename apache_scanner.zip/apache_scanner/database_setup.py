#!/usr/bin/env python3
from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine


Base = declarative_base()

class User(Base):
    __tablename__ = 'user'

    id = Column(Integer, primary_key=True)
    name = Column(String(250), nullable=False)
    email = Column(String(250), nullable=False)
    gender = Column(String(250))


class Page(Base):
    __tablename__ = 'page'
    id = Column(Integer, primary_key=True)
    page_name = Column(String(250))
    url = Column(String(250))

class Element(Base):
    __tablename__ = 'element'

    id = Column(Integer, primary_key=True)
    name = Column(String(80))
    page_id = Column(Integer, ForeignKey('page.id'))
    page = relationship(Page)

    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'name': self.name,
            'page_id': self.page_id,
        }

class ElementsMeta(Base):
    __tablename__ = 'elements_meta'

    id = Column(Integer, primary_key=True)
    name = Column(String(255))
    element_text = Column(String(255))
    element_html = Column(String(255))
    element_class = Column(String(255))
    element_src = Column(String(500))
    element_id = Column(Integer, ForeignKey('element.id'))
    element = relationship(Element)
    page_id = Column(Integer, ForeignKey('page.id'))
    page = relationship(Page)

    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'name': self.name,
            'element_text': self.element_text,
            'element_html': self.element_html,
            'element_class': self.element_class,
			'element_src': self.element_src,
			'element_id': self.element_id,
            'page_id': self.page_id
        }

class Vote(Base):
    __tablename__ = 'vote'

    id = Column(Integer, primary_key=True)
    likes = Column(Integer)
    dislike = Column(Integer)


    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'likes': self.likes,
            'dislike': self.dislike,
            'id': self.id,
        }


engine = create_engine('sqlite:///skanner.db')
Base.metadata.create_all(engine)
