#!/usr/bin/python
from bs4 import BeautifulSoup
from tablib import Dataset
import numpy as np
import excel
import matplotlib.pyplot as plt
from flask import Flask, render_template, request, redirect, jsonify, url_for, flash
from sqlalchemy import create_engine, asc
from sqlalchemy.orm import sessionmaker
from database_setup import Base, User, Element, ElementsMeta, Vote
from flask import session as login_session
import string
import excel
# IMPORTS FOR THIS STEP
import httplib2
import json
from flask import make_response
import requests
import pandas as pd
from tablib import Dataset
import numpy as np
import excel
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
# IMPORTS FOR THIS STEP
import pprint
import httplib2
import json
import sqlite3
from flask import make_response
import requests


app = Flask(__name__)

APPLICATION_NAME = "skaner"

# Connect to Database and create database session
engine = create_engine('sqlite:///skanner.db')
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()



# You need install :
# pip install PyPDF2 - > Read and parse your content pdf
# pip install requests - > request for get the pdf
# pip install BeautifulSoup - > for parse the html and find all url hrf with ".pdf" final
from PyPDF2 import PdfFileReader
import requests
import io
from bs4 import BeautifulSoup


@app.route('/skanner/JSON')
def endElements():
    elements = session.query(Element).all()
    return jsonify(Elements=[r.serialize for r in elements])

@app.route('/skanner/meta/JSON')
def endElementsMeta():
    metas = session.query(ElementsMeta).all()
    return jsonify(Elements_meta=[r.serialize for r in metas])

@app.route('/')
def skanner():
    with open('index.html', 'r') as f:
        contents = f.read()
        soup = BeautifulSoup(contents, 'lxml')
        projectData = []
        #projectData.append(str(soup.h2.name))
        #projectData.append(str(soup.h2.text))
        #projectData.append(str(soup.li))
        for child in soup.recursiveChildGenerator():

            if child.name:
                newElement = Element(name=str(child.name))
                session.add(newElement)
                print('Skanner Found new Creating New Element... ')
                newMeta = ElementsMeta(element_text=str(child.text), element_html=str(child),
                element_id=newElement.id)
                print('Creating New Meta... ')
                session.add(newMeta)
                session.commit()
        return "Beauty Skanner Finished His Work Successfuly your data ready!.."


@app.route('/play/<string:tag_nam>')
def play(tag_nam):
    getelem = session.query(Element).filter_by(name=tag_nam).all()
    text = ""
    for i in getelem:
        text += "<div style='width:200px;margin-left:auto;margin-right:auto;border:2px solid gold; height:100px;"
        text += "background-color:lightblue;color:white;text-align:center;'>"
        text += '<h4>' + str(i.name) + '<h4>'
        text += "</div>"
    return text


    #element_text = Column(String(255))
    #element_html = Column(String(255))
    #element_class = Column(String(255))
    #element_src = Column(String(500))
    #element_id = Column(Integer, ForeignKey('element.id'))
    #element = relationship(Element)


    #newSeries = Series(name=iname, description=ides, hero=ihero, menu_id=imenuid)
    #imge = newSeries.image



if __name__ == '__main__':
    app.secret_key = 'AS&S^1234Aoshsheo152h23h5j7ks9-1---3*-s,#k>s'
    app.debug = True
    app.run(host='0.0.0.0', port=5000, threaded=False)
